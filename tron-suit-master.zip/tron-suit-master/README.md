tron-suit
=========

MSGEQ7 + LPD8806 strips + RGB Character LCD + Serial Coms